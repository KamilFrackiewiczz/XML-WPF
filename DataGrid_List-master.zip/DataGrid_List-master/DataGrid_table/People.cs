﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DataGrid_table
{

    class People
    {
        public enum Gender
        {
            Male,
            Female
        }
        public int ID { get; set; }
        public static int nextID = 1;

        public string Name { get; set; }
        public int Age { get; set; }
        public Gender _Gender { set; get; }
        public string Email { get; set; }
        public string Description { get; set; }


        public People(string name, int age,Gender gender, string email, string desctription )
        {
            this.ID = nextID++;
            this.Name = name;
            this.Age = age;
            this._Gender = gender;
            this.Email = email;
            this.Description = desctription;
        }
    }
}
