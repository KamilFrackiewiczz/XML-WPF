﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;

namespace DataGrid_table
{
    class GenderTemplateSelector : DataTemplateSelector
    {
        public DataTemplate MaleTemplate { get; set; }
        public DataTemplate FemaleTemplate { get; set; }
        public override DataTemplate SelectTemplate(object item, DependencyObject container)
        {

            People person = item as People;

            if (person._Gender == People.Gender.Male)
                return MaleTemplate;
            return FemaleTemplate;
        }

    }
}
