﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataGrid_table
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ObservableCollection<People> peopleList = new ObservableCollection<People>();
        public MainWindow()
        {
            

            InitializeComponent();

            peopleList.Add(new People("Adam", 40,People.Gender.Male, "Adam@gmail.com","To jest Adam witam"));
            peopleList.Add(new People("Kamil", 22, People.Gender.Male, "Kamil@gmail.com", "Dobry ziom"));
            peopleList.Add(new People("Ula", 20, People.Gender.Female, "Ulcia@gmail.com", "Spoko dziewczyna"));
            peopleList.Add(new People("Andżelika", 20, People.Gender.Female, "Andzia@gmail.com", "Szkoda gadać"));


            DataGrid.ItemsSource = peopleList;
            ComboBoxItemGender.ItemsSource = Enum.GetValues(typeof(People.Gender));
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string temp_name = NameBox.Text;
            int temp_age = Convert.ToInt32(AgeBox.Text);
            string temp_email = EmailBox.Text;
            string temp_description = DescriptionBox.Text;

            People.Gender temp_gender = People.Gender.Female;

            if (GenderBox.IsChecked == true)
            {
                temp_gender = People.Gender.Male;
            }
            peopleList.Add(new People(temp_name, temp_age, temp_gender, temp_email, temp_description));
            
                 
        }
    }
}
