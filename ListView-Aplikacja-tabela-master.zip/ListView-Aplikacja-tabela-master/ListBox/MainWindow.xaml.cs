﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ListBox
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 

    public partial class MainWindow : Window
    {
        public ObservableCollection<Figures> figures_list = new ObservableCollection<Figures>();
        public MainWindow()
        {
            InitializeComponent();

            figures_list.Add(new Figures("Trójkąt", "Czerwony"));
            figures_list.Add(new Figures("Kwadrat", "Żółty"));
            figures_list.Add(new Figures("Prostokąt", "Niebieski"));
            figures_list.Add(new Figures("Okrąg", "Pomarańczowy"));

            mainListBox.ItemsSource = figures_list;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string boxName = figurebox.Text;
            string boxColor = colorbox.Text;

            figures_list.Add(new Figures(boxName, boxColor));
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Figures selectedRow = (Figures)mainListBox.SelectedItem;

            try
            {
                figures_list.Remove(selectedRow);
            }
            catch (System.ArgumentOutOfRangeException)
            {
                MessageBox.Show("Wybierz element!");
            }

            
        }

        private void GridViewColumnHeader_Click(object sender, RoutedEventArgs e)
        {
            GridViewColumnHeader source = (sender as GridViewColumnHeader);
            string columnNameToSort = source.Content.ToString();

            CollectionView view = (CollectionView)CollectionViewSource.GetDefaultView(mainListBox.ItemsSource);
            ListSortDirection howToSort = ListSortDirection.Ascending;
            

            if (view.SortDescriptions.Any())
            {
                
                SortDescription item = view.SortDescriptions.ElementAt(0);
                if(columnNameToSort == item.PropertyName.ToString())
                {

                    if (item.Direction == ListSortDirection.Ascending)

                        howToSort = ListSortDirection.Descending;
                    else
                    {
                        MessageBox.Show("XD");
                        howToSort = ListSortDirection.Ascending;
                    }

                    

                }

            }

            view.SortDescriptions.Clear();

            view.SortDescriptions.Add(new SortDescription(columnNameToSort,howToSort));
        }
    }
}
