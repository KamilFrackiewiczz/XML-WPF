﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using System.Text;

namespace ListBox
{
    public class Figures
    {
        public string figure { get; set; }
        public string color { get; set; }
        public static int nextId { get; set; }
        public int id { get; set; }

        public Figures()
        {

        }
        public Figures(string figure, string color)
        {
            this.figure = figure;
            this.color = color;
            this.id = nextId;
            nextId++;
        }

        
    }
}
