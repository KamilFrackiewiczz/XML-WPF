﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ContentPresenter
{
    class Sex
    {
        public string Imie { get; set; }
        public string Plec { get; set; }

        public Sex()
        {

        }

    }
}
