﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using System.Windows.Controls;
using System.Linq;
using System.Threading.Tasks;

namespace DataContext_propertyChange
{
    class InkEditingModes : INotifyPropertyChanged
    {
        private InkCanvasEditingMode _Editingmode;
        public InkCanvasEditingMode EditingMode
        {
            get
            {
                return _Editingmode;
            }
            set
            {
                _Editingmode = value;
                if(PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs("EditingMode"));
            }
        }
        
        public InkEditingModes()
        {
            _Editingmode = InkCanvasEditingMode.Select;
        }

        
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
