﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DataTrigger_itemsource_itemscontrol_datatemplate
{
    public class MyImage
    {
        public string MyImagePath { get; set; }
        public string MyImageName { get; set; }
        public bool isFound { get; set; }
        public string NoImage { get; set; } = "nothing.png";

      public MyImage()
        {
            this.MyImagePath = "check.png";
            this.MyImageName = "Logo";
        }
       public MyImage(string MyImagePath,string MyImageName)
        {
            string Absolutepath = Path.Combine(Directory.GetCurrentDirectory(), MyImagePath);

            this.MyImagePath = MyImagePath;
            this.MyImageName = MyImageName;

            isFound = File.Exists(Absolutepath);
        }
    }
}
