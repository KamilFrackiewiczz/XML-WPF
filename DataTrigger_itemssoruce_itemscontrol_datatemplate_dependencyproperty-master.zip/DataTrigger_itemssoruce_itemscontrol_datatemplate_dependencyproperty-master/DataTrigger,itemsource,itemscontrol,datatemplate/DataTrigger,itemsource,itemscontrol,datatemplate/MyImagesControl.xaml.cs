﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DataTrigger_itemsource_itemscontrol_datatemplate
{
    /// <summary>
    /// Logika interakcji dla klasy MyImagesControl.xaml
    /// </summary>
    public partial class MyImagesControl : UserControl
    {
        private int _Szerokosc;
        public int Szerokosc
        {
            get
            {
                return _Szerokosc;
            }
            set
            {
                _Szerokosc = value;
                this.Width = _Szerokosc;
            }
        }

        private Brush _Tlo;
        public Brush Tlo
        {
            get
            {
                return _Tlo;
            }
            set
            {
                _Tlo = value;
                this.Background = _Tlo;
            }
        }

        public List<MyImage> MyImageSource
        {
            get
            {
                return (List<MyImage>)GetValue(MyImageSourceProperty);
            }
            set
            {
                SetValue(MyImageSourceProperty, value);
            }
        }

        // Using a DependencyProperty as the backing store for MyImageSourceProperty.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty MyImageSourceProperty =
            DependencyProperty.Register("MyImageSource", typeof(List<MyImage>), typeof(MyImagesControl), new PropertyMetadata(null, new PropertyChangedCallback((s, e) =>

             {
                 var source = s as MyImagesControl;

                 source.ContainterList.ItemsSource = (List<MyImage>)e.NewValue;
             }
            )));

        public MyImagesControl()
        {
            InitializeComponent();
        }
    }
}
