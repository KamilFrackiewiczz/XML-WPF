﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace KolkoIKrzyzyk
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        static bool isClicked00 = false;
        static bool isClicked01 = false;
        static bool isClicked02 = false;

        static bool isClicked10 = false;
        static bool isClicked11 = false;
        static bool isClicked12 = false;

        static bool isClicked20 = false;
        static bool isClicked21 = false;
        static bool isClicked22 = false;


        static string symbol00 = "00";
        static string symbol01 = "01";
        static string symbol02 = "02";

        static string symbol10 = "10";
        static string symbol11 = "11";
        static string symbol12 = "12";

        static string symbol20 = "20";
        static string symbol21 = "21";
        static string symbol22 = "22";

        static string tempSymb;
        public MainWindow()
        {
            InitializeComponent();
           

        }

        private static void Check_for_win()
        {
            if(Check_horitzontal() == true | Check_vertical() == true | Check_cross() == true)
            {
                MessageBox.Show("Wygrana!", "Brawo", MessageBoxButton.OK);               
                Application.Current.Shutdown();
                              
            }



        }

        private static bool Check_vertical()
        {
            if (symbol00 == symbol10 & symbol10 == symbol20)
            {
                return true;
            }
            if (symbol01 == symbol11 & symbol11 == symbol21)
            {
                return true;
            }
            if (symbol02 == symbol12 & symbol12 == symbol22)
            {
                return true;
            }
            return false;
        }
        private static bool Check_horitzontal()
        {
            if(symbol00 == symbol01 & symbol01 == symbol02)
            {
                return true;
            }
            if (symbol10 == symbol11 & symbol11 == symbol12)
            {
                return true;
            }
            if (symbol20 == symbol21 & symbol21 == symbol22)
            {
                return true;
            }
            return false;

        }
        private static bool Check_cross()
        {
            if(symbol00 == symbol11 & symbol11 == symbol22)
            {
                return true;
            }
            if(symbol02 == symbol11 & symbol11 == symbol20)
            {
                return true;
            }
            return false;
        }


        public void B00_Click(object sender, RoutedEventArgs e)
        {

            if (isClicked00 == false) {

                tempSymb = Turn.getSymbol();
                if (tempSymb == "X") B00.Foreground = Brushes.Red; else B00.Foreground = Brushes.Blue; 
                B00.Content = tempSymb;
                isClicked00 = true;
                symbol00 = tempSymb;
                Check_for_win();
                
                
            }
           
        }

        private void B01_Click(object sender, RoutedEventArgs e)
        {
            if (isClicked01 == false)
            {
                tempSymb = Turn.getSymbol();
                if (tempSymb == "X") B01.Foreground = Brushes.Red; else B01.Foreground = Brushes.Blue;
                B01.Content = tempSymb;
                isClicked01 = true;
                symbol01 = tempSymb;
                Check_for_win();
            }
        }

        private void B02_Click(object sender, RoutedEventArgs e)
        {
            if (isClicked02 == false)
            {
                tempSymb = Turn.getSymbol();
                if (tempSymb == "X") B02.Foreground = Brushes.Red; else B02.Foreground = Brushes.Blue;
                B02.Content = tempSymb;
                isClicked02 = true;
                symbol02 = tempSymb;
                Check_for_win();
            }
        }

        private void B10_Click(object sender, RoutedEventArgs e)
        {
            if (isClicked10 == false)
            {
                tempSymb = Turn.getSymbol();
                if (tempSymb == "X") B10.Foreground = Brushes.Red; else B10.Foreground = Brushes.Blue;
                B10.Content = tempSymb;
                isClicked10 = true;
                symbol10 = tempSymb;
                Check_for_win();
            }
        }

        private void B11_Click(object sender, RoutedEventArgs e)
        {
            if (isClicked11 == false)
            {
                tempSymb = Turn.getSymbol();
                if (tempSymb == "X") B11.Foreground = Brushes.Red; else B11.Foreground = Brushes.Blue;
                B11.Content = tempSymb;
                isClicked11 = true;
                symbol11 = tempSymb;
                Check_for_win();
            }
        }

        private void B12_Click(object sender, RoutedEventArgs e)
        {
            if (isClicked12 == false)
            {
                tempSymb = Turn.getSymbol();
                if (tempSymb == "X") B12.Foreground = Brushes.Red; else B12.Foreground = Brushes.Blue;
                B12.Content = tempSymb;
                isClicked12 = true;
                symbol12 = tempSymb;
                Check_for_win();
            }
        }

        private void B20_Click(object sender, RoutedEventArgs e)
        {
            if (isClicked20 == false)
            {
                tempSymb = Turn.getSymbol();
                if (tempSymb == "X") B20.Foreground = Brushes.Red; else B20.Foreground = Brushes.Blue;
                B20.Content = tempSymb;
                isClicked20 = true;
                symbol20 = tempSymb;
                Check_for_win();
            }
        }

        private void B21_Click(object sender, RoutedEventArgs e)
        {
            if (isClicked21 == false)
            {
                tempSymb = Turn.getSymbol();
                if (tempSymb == "X") B21.Foreground = Brushes.Red; else B21.Foreground = Brushes.Blue;
                B21.Content = tempSymb;
                isClicked21 = true;
                symbol21 = tempSymb;
                Check_for_win();
            }
        }

        private void B22_Click(object sender, RoutedEventArgs e)
        {
            if (isClicked22 == false)
            {
                tempSymb = Turn.getSymbol();
                if (tempSymb == "X") B22.Foreground = Brushes.Red; else B22.Foreground = Brushes.Blue;
                B22.Content = tempSymb;
                isClicked22 = true;
                symbol22 = tempSymb;
                Check_for_win();
            }
        }
    }
}
