﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;

namespace KolkoIKrzyzyk
{
    class Turn
    {
        private static int turn = 1;

        public static void nextTurn()
        {
            turn++;
            if (turn == 3)
            {
                turn = 1;
            } 
        }

        public static String getSymbol()
        {
            int tempTurn = turn;
            string symbol = "X";
            nextTurn();

            if (tempTurn == 2) symbol = "O";

            return symbol;
            
            
        }

    }
}
