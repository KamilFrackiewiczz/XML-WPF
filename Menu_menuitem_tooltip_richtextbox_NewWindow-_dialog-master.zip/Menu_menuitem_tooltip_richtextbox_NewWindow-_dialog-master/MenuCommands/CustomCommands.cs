﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;

namespace MenuCommands
{
    public static class CustomCommands
    {
        public static readonly RoutedUICommand Exit = new RoutedUICommand(
            "Wyjscie",
            "Exit",
            typeof(CustomCommands),
            new InputGestureCollection()
            {
                new KeyGesture(Key.Q,ModifierKeys.Control)
            }
            );
    }
}
